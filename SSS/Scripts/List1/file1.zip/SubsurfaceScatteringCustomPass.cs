// =============================================================================
//  SubsurfaceScatteringCustomPass.cs
//  desc : HDRP (17.3.0 / Unity 6) 的屏幕空间 SSS Custom Pass。
//         复刻所给前向渲染 SSS 流程的三段式结构：
//           Stage 1  Split Lighting : 用 ShaderTag 把 SSS 物体的「漫反射辐照度」
//                                      和「反照率」分别画进 MRT(diffuse / albedo)
//           Stage 2  Scatter        : 用 disc kernel 做屏幕空间散射(模糊)
//                                      Compute 优先，Shader(fragment) 回退
//           Stage 3  Composite      : 把散射后的漫反射颜色加法叠加回相机颜色
//
//  注入点建议：CustomPassVolume 设为 AfterOpaqueAndSky 或 BeforePostProcess。
//
//  ⚠ 关键约定 / 集成缝：
//   - SSS 材质的 Shader 需要提供一个 LightMode = "SubsurfaceDiffuse" 的 Pass，
//     输出：SV_Target0 = 漫反射辐照度(不含反照率), a=1; SV_Target1 = 反照率。
//     见随附 SubsurfaceDiffuse_Example.hlsl。
//   - 该 SubsurfaceDiffuse Pass 应只输出「漫反射」分量；高光/透射等仍由材质主 Pass
//     画进相机颜色。本 Custom Pass 用加法把散射后的漫反射补回去，避免重复计上漫反射。
//   - 为方便起步，可勾选 setMainLightGlobals，本 Pass 会把场景主平行光写成全局量，
//     示例 SubsurfaceDiffuse Pass 用它做单光源 Lambert。多光源需自行接 HDRP light loop。
// =============================================================================

using System;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using UnityEngine.Rendering.RendererUtils;

[Serializable]
public class SubsurfaceScatteringCustomPass : CustomPass
{
    // ---------------- Inspector 可调 ----------------
    [Header("Resources")]
    public ComputeShader scatterCompute;          // SSS_ScreenSpaceScatter.compute
    public Shader        scatterShader;           // SSS_ScreenSpaceScatter.shader (回退 + 合成)
    public Texture2D     discKernel;              // SSS_DiscSampling.GenerateDiscKernel 产物 (N×1)

    [Header("Split Lighting")]
    [Tooltip("SSS 材质用于输出漫反射辐照度+反照率的 Pass 的 LightMode")]
    public string        subsurfaceDiffuseTag = "SubsurfaceDiffuse";

    [Header("Scattering")]
    public bool          preferCompute   = true;  // 平台支持时优先 Compute
    public bool          remultiplyAlbedo = true;  // 散射后乘回反照率(= 最终漫反射颜色)

    [Tooltip("整体散射半径倍率")]
    public float         radiusMultiplier = 1.0f;
    [Tooltip("kernel 半径是 mm，这里是 1 世界单位 = ? 米（米/世界单位）。默认 1。")]
    public float         worldScale       = 1.0f;
    [Tooltip("单轴最大像素偏移，限制过大模糊")]
    public float         maxRadiusPixels  = 64.0f;
    [Tooltip("深度剔除强度，越大跨深度越容易被剔除")]
    public float         depthFalloff     = 1.0f;

    [Header("Main Light (示例 SubsurfaceDiffuse Pass 用)")]
    public bool          setMainLightGlobals = true;
    public Light         mainLight;               // 不填则用 RenderSettings.sun

    // ---------------- 内部资源 ----------------
    RTHandle _diffuseRT;     // rgb = 漫反射辐照度, a = coverage
    RTHandle _albedoRT;      // rgb = 反照率
    RTHandle _lightingRT;    // 散射结果（compute 需 randomWrite）

    Material _scatterMat;
    int      _kernelScatter = -1;

    RenderTargetIdentifier[] _splitMRT;
    readonly ShaderTagId[]   _shaderTags = new ShaderTagId[1];

    const int kPassScatterFallback = 0;
    const int kPassComposite       = 1;

    // ---------------- Shader 属性 ID ----------------
    static class SID
    {
        public static readonly int IrradianceSource = Shader.PropertyToID("_SSSIrradianceSource");
        public static readonly int Albedo           = Shader.PropertyToID("_SSSAlbedo");
        public static readonly int DiscKernel       = Shader.PropertyToID("_DiscKernel");
        public static readonly int DepthTexture     = Shader.PropertyToID("_SSSDepthTexture");
        public static readonly int Output           = Shader.PropertyToID("_SSSOutput");
        public static readonly int ScatterResult    = Shader.PropertyToID("_SSSScatterResult");

        public static readonly int ScreenSize       = Shader.PropertyToID("_SSSScreenSize");
        public static readonly int KernelCount       = Shader.PropertyToID("_DiscKernelCount");
        public static readonly int ZBufferParams     = Shader.PropertyToID("_SSSZBufferParams");
        public static readonly int PixelScale        = Shader.PropertyToID("_SSSPixelScale");
        public static readonly int MaxRadiusPx       = Shader.PropertyToID("_SSSMaxRadiusPx");
        public static readonly int DepthFalloff      = Shader.PropertyToID("_SSSDepthFalloff");

        public static readonly int MainLightDir      = Shader.PropertyToID("_SSSMainLightDir");
        public static readonly int MainLightColor    = Shader.PropertyToID("_SSSMainLightColor");
    }

    const string kKeywordRemultiply = "SSS_REMULTIPLY_ALBEDO";

    // =========================================================================
    protected override void Setup(ScriptableRenderContext renderContext, CommandBuffer cmd)
    {
        if (scatterShader != null)
            _scatterMat = CoreUtils.CreateEngineMaterial(scatterShader);

        if (scatterCompute != null)
            _kernelScatter = scatterCompute.FindKernel("SSSScatter");

        // diffuse(辐照度) + albedo：half 浮点，Point，全分辨率
        _diffuseRT = RTHandles.Alloc(
            Vector2.one, slices: TextureXR.slices, dimension: TextureXR.dimension,
            colorFormat: GraphicsFormat.R16G16B16A16_SFloat,
            filterMode: FilterMode.Point, wrapMode: TextureWrapMode.Clamp,
            useDynamicScale: true, name: "_SSSDiffuse");

        _albedoRT = RTHandles.Alloc(
            Vector2.one, slices: TextureXR.slices, dimension: TextureXR.dimension,
            colorFormat: GraphicsFormat.R16G16B16A16_SFloat,
            filterMode: FilterMode.Point, wrapMode: TextureWrapMode.Clamp,
            useDynamicScale: true, name: "_SSSAlbedo");

        // lighting：compute 需要 randomWrite
        _lightingRT = RTHandles.Alloc(
            Vector2.one, slices: TextureXR.slices, dimension: TextureXR.dimension,
            colorFormat: GraphicsFormat.R16G16B16A16_SFloat,
            filterMode: FilterMode.Point, wrapMode: TextureWrapMode.Clamp,
            enableRandomWrite: true, useDynamicScale: true, name: "_SSSLighting");

        _splitMRT = new RenderTargetIdentifier[2];
    }

    // =========================================================================
    protected override void Execute(CustomPassContext ctx)
    {
        if (!Validate())
            return;

        var hd  = ctx.hdCamera;
        var cmd = ctx.cmd;
        int w   = hd.actualWidth;
        int h   = hd.actualHeight;

        // 主光源全局量（供示例 SubsurfaceDiffuse Pass 用）
        if (setMainLightGlobals)
            PushMainLightGlobals(cmd);

        // ---- Stage 1: Split Lighting → diffuse / albedo (MRT) ----
        RenderSplitLighting(ctx);

        // ---- 公共散射参数 ----
        bool useCompute = preferCompute
                          && scatterCompute != null
                          && _kernelScatter >= 0
                          && SystemInfo.supportsComputeShaders;

        Vector4 zParams   = GetZBufferParams(hd.camera);
        float   pixelScale = ComputePixelScale(hd, h);
        int     kernelN    = discKernel.width;

        // ---- Stage 2: Scatter (compute 优先, fragment 回退) → lightingRT ----
        if (useCompute)
            DispatchScatterCompute(cmd, ctx.cameraDepthBuffer, w, h, kernelN, zParams, pixelScale);
        else
            DrawScatterFallback(ctx, w, h, kernelN, zParams, pixelScale);

        // ---- Stage 3: Composite (加法叠加回相机颜色) ----
        _scatterMat.SetTexture(SID.ScatterResult, _lightingRT);
        _scatterMat.SetVector(SID.ScreenSize, new Vector4(w, h, 1f / w, 1f / h));
        CoreUtils.DrawFullScreen(cmd, _scatterMat, ctx.cameraColorBuffer, ctx.propertyBlock, kPassComposite);
    }

    // -------------------------------------------------------------------------
    bool Validate()
    {
        if (discKernel == null) return false;
        if (_scatterMat == null && scatterShader != null)
            _scatterMat = CoreUtils.CreateEngineMaterial(scatterShader);
        return _scatterMat != null;
    }

    // -------------------------------------------------------------------------
    void RenderSplitLighting(CustomPassContext ctx)
    {
        _shaderTags[0] = new ShaderTagId(subsurfaceDiffuseTag);

        var desc = new RendererListDesc(_shaderTags, ctx.cullingResults, ctx.hdCamera.camera)
        {
            renderQueueRange = RenderQueueRange.opaque,
            sortingCriteria  = SortingCriteria.CommonOpaque,
            // 让 HDRP 把光照贴图/光照探针/阴影遮罩等逐物体数据喂给 SubsurfaceDiffuse Pass
            rendererConfiguration = PerObjectData.LightProbe
                                  | PerObjectData.Lightmaps
                                  | PerObjectData.LightProbeProxyVolume
                                  | PerObjectData.ShadowMask
                                  | PerObjectData.OcclusionProbe,
            excludeObjectMotionVectors = false,
        };

        var rl = ctx.renderContext.CreateRendererList(desc);

        _splitMRT[0] = _diffuseRT;
        _splitMRT[1] = _albedoRT;

        // 用相机深度做 ZTest（SubsurfaceDiffuse Pass 内 ZTest Equal / ZWrite Off）
        // 两张 MRT 清成 (0,0,0,0)，coverage=0 → 非 SSS 区域散射不产生贡献
        CoreUtils.SetRenderTarget(ctx.cmd, _splitMRT, ctx.cameraDepthBuffer,
            ClearFlag.Color, Color.clear);

        ctx.cmd.DrawRendererList(rl);
    }

    // -------------------------------------------------------------------------
    void DispatchScatterCompute(CommandBuffer cmd, RTHandle depth, int w, int h, int kernelN,
        Vector4 zParams, float pixelScale)
    {
        CoreUtils.SetKeyword(scatterCompute, kKeywordRemultiply, remultiplyAlbedo);

        cmd.SetComputeTextureParam(scatterCompute, _kernelScatter, SID.IrradianceSource, _diffuseRT);
        cmd.SetComputeTextureParam(scatterCompute, _kernelScatter, SID.Albedo, _albedoRT);
        cmd.SetComputeTextureParam(scatterCompute, _kernelScatter, SID.DiscKernel, discKernel);
        cmd.SetComputeTextureParam(scatterCompute, _kernelScatter, SID.DepthTexture, depth);
        cmd.SetComputeTextureParam(scatterCompute, _kernelScatter, SID.Output, _lightingRT);

        cmd.SetComputeIntParams (scatterCompute, SID.ScreenSize, w, h);
        cmd.SetComputeIntParam  (scatterCompute, SID.KernelCount, kernelN);
        cmd.SetComputeVectorParam(scatterCompute, SID.ZBufferParams, zParams);
        cmd.SetComputeFloatParam(scatterCompute, SID.PixelScale, pixelScale);
        cmd.SetComputeFloatParam(scatterCompute, SID.MaxRadiusPx, maxRadiusPixels);
        cmd.SetComputeFloatParam(scatterCompute, SID.DepthFalloff, depthFalloff);

        int tx = (w + 15) / 16;
        int ty = (h + 15) / 16;
        cmd.DispatchCompute(scatterCompute, _kernelScatter, tx, ty, 1);
    }

    // -------------------------------------------------------------------------
    void DrawScatterFallback(CustomPassContext ctx, int w, int h, int kernelN,
        Vector4 zParams, float pixelScale)
    {
        CoreUtils.SetKeyword(_scatterMat, kKeywordRemultiply, remultiplyAlbedo);

        _scatterMat.SetTexture(SID.IrradianceSource, _diffuseRT);
        _scatterMat.SetTexture(SID.Albedo, _albedoRT);
        _scatterMat.SetTexture(SID.DiscKernel, discKernel);
        _scatterMat.SetTexture(SID.DepthTexture, ctx.cameraDepthBuffer);

        _scatterMat.SetVector(SID.ScreenSize, new Vector4(w, h, 1f / w, 1f / h));
        _scatterMat.SetInt   (SID.KernelCount, kernelN);
        _scatterMat.SetVector(SID.ZBufferParams, zParams);
        _scatterMat.SetFloat (SID.PixelScale, pixelScale);
        _scatterMat.SetFloat (SID.MaxRadiusPx, maxRadiusPixels);
        _scatterMat.SetFloat (SID.DepthFalloff, depthFalloff);

        CoreUtils.DrawFullScreen(ctx.cmd, _scatterMat, _lightingRT, ctx.propertyBlock, kPassScatterFallback);
    }

    // -------------------------------------------------------------------------
    void PushMainLightGlobals(CommandBuffer cmd)
    {
        Light l = mainLight != null ? mainLight : RenderSettings.sun;
        if (l != null && l.type == LightType.Directional)
        {
            Vector3 dir = -l.transform.forward;             // 指向光源
            Color   c   = l.color * l.intensity;
            cmd.SetGlobalVector(SID.MainLightDir, new Vector4(dir.x, dir.y, dir.z, 0f));
            cmd.SetGlobalVector(SID.MainLightColor, new Vector4(c.r, c.g, c.b, 0f));
        }
        else
        {
            cmd.SetGlobalVector(SID.MainLightDir, new Vector4(0f, 1f, 0f, 0f));
            cmd.SetGlobalVector(SID.MainLightColor, Vector4.zero);
        }
    }

    // -------------------------------------------------------------------------
    // mm→像素偏移系数（与 shader 内 /depth 配合）。
    // 像素偏移/米 = 0.5 * P11 * height / viewDepth（竖直 FOV 定义，xy 同系数）。
    // 再乘 0.001(mm→m)、radiusMultiplier、worldScale。
    float ComputePixelScale(HDCamera hd, int height)
    {
        float p11 = hd.camera.projectionMatrix.m11; // = 1/tan(fovY/2)
        float perMeter = 0.5f * p11 * height;
        return perMeter * 0.001f * Mathf.Max(0f, radiusMultiplier) * Mathf.Max(1e-4f, worldScale);
    }

    // -------------------------------------------------------------------------
    // 复刻 Unity _ZBufferParams（含 reverse-Z 处理）。LinearEyeDepth = 1/(z*d + w)。
    static Vector4 GetZBufferParams(Camera cam)
    {
        double n = cam.nearClipPlane;
        double f = cam.farClipPlane;
        double x = 1.0 - f / n;
        double y = f / n;
        if (SystemInfo.usesReversedZBuffer)
        {
            x = -1.0 + f / n;
            y = 1.0;
        }
        return new Vector4((float)x, (float)y, (float)(x / f), (float)(y / f));
    }

    // =========================================================================
    protected override void Cleanup()
    {
        _diffuseRT?.Release();
        _albedoRT?.Release();
        _lightingRT?.Release();
        CoreUtils.Destroy(_scatterMat);
    }
}
